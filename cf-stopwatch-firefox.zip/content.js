(function () {
  'use strict';

  function getProblemInfo() {
    const path = window.location.pathname;
    let contestId, problemIndex;
    let m = path.match(/\/(contest|gym)\/(\d+)\/problem\/([A-Za-z0-9]+)/i);
    if (m) {
      contestId = m[2]; problemIndex = m[3].toUpperCase();
    } else {
      m = path.match(/\/problemset\/problem\/(\d+)\/([A-Za-z0-9]+)/i);
      if (m) { contestId = m[1]; problemIndex = m[2].toUpperCase(); }
    }
    if (!contestId) return null;
    const problemId = `${contestId}${problemIndex}`;
    const titleEl = document.querySelector('.problem-statement .title');
    const title = titleEl
      ? titleEl.textContent.trim().replace(/^[A-Z0-9]+\.\s*/, '')
      : problemId;
    let rating = null;
    document.querySelectorAll('.tag-box').forEach(tag => {
      const n = parseInt(tag.textContent.trim(), 10);
      if (!isNaN(n) && n >= 800 && n <= 3500) rating = n;
    });
    return { problemId, contestId, problemIndex, title, rating };
  }

  function getUserHandle() {
    const els = document.querySelectorAll(
      '#header .lang-chooser a[href^="/profile/"], a.username, a[href^="/profile/"]'
    );
    for (const el of els) {
      const m = el.getAttribute('href').match(/^\/profile\/(.+)/);
      if (m && m[1]) return m[1];
    }
    return null;
  }

  const info = getProblemInfo();
  if (!info) return;

  const handle = getUserHandle();
  const SESSION_KEY = `session_${info.problemId}`;

  let session = null;
  let runStartedAt = null;

  let timerEl, statusEl, attemptsEl, reattemptBtn;
  let tickId      = null;
  let pollId      = null;
  let countdownId = null;
  let countdownSecs = 60;

  // ─── STORAGE ─────────────────────────────────────────────────────────────

  async function loadSession() {
    const r = await browser.storage.local.get(SESSION_KEY);
    return r[SESSION_KEY] || null;
  }

  function persistSession() {
    const toStore = Object.assign({}, session, { runStartedAt: undefined });
    browser.storage.local.set({ [SESSION_KEY]: toStore });
  }

  // ─── ELAPSED ─────────────────────────────────────────────────────────────

  function getElapsed() {
    if (!session) return 0;
    if (session.state === 'solved') return session.finalTimeMs;
    if (session.state === 'running' && runStartedAt !== null)
      return session.accumulated + (Date.now() - runStartedAt);
    return session.accumulated;
  }

  function fmt(ms) {
    const s  = Math.floor(Math.max(0, ms) / 1000);
    const h  = Math.floor(s / 3600);
    const m  = Math.floor((s % 3600) / 60);
    const sc = s % 60;
    const mm = String(m).padStart(2, '0');
    const ss = String(sc).padStart(2, '0');
    return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
  }

  // ─── UI ──────────────────────────────────────────────────────────────────

  function injectWidget() {
    const sidebar =
      document.querySelector('.roundbox.sidebox') ||
      document.querySelector('#sidebar') ||
      document.querySelector('.sidebar') ||
      document.querySelector('[class*="sidebox"]');
    const w = buildWidget();
    if (sidebar) sidebar.insertBefore(w, sidebar.firstChild);
    else { w.classList.add('cf-sw-floating'); document.body.appendChild(w); }
  }

  function buildWidget() {
    const wrap = document.createElement('div');
    wrap.id = 'cf-sw-widget';
    const badge = info.rating
      ? `<span class="cf-sw-badge">⭐ ${info.rating}</span>`
      : `<span class="cf-sw-badge cf-sw-badge--unknown">Unrated</span>`;
    wrap.innerHTML = `
      <div class="cf-sw-head">
        <span class="cf-sw-label">Stopwatch</span>
        ${badge}
      </div>
      <div class="cf-sw-problem-title">${escHtml(info.title)}</div>
      <div class="cf-sw-timer" id="cf-sw-timer">00:00</div>
      <div class="cf-sw-status" id="cf-sw-status">
        <span class="cf-sw-dot" id="cf-sw-dot"></span>
        <span id="cf-sw-status-text">Ready</span>
      </div>
      <div class="cf-sw-meta">
        <span id="cf-sw-attempts">Attempt #1</span>
      </div>
      <div class="cf-sw-actions">
        <div id="cf-sw-start-area">
          <button class="cf-sw-btn cf-sw-btn--start" id="cf-sw-start-btn">▶ Start Solving</button>
          <div class="cf-sw-hint" id="cf-sw-hint">auto-starts in 60s</div>
        </div>
        <div id="cf-sw-reattempt-area" style="display:none">
          <button class="cf-sw-btn" id="cf-sw-reattempt">↺ Reattempt</button>
        </div>
      </div>
    `;
    timerEl      = wrap.querySelector('#cf-sw-timer');
    statusEl     = wrap.querySelector('#cf-sw-status');
    attemptsEl   = wrap.querySelector('#cf-sw-attempts');
    reattemptBtn = wrap.querySelector('#cf-sw-reattempt');
    wrap.querySelector('#cf-sw-start-btn').addEventListener('click', startSolving);
    reattemptBtn.addEventListener('click', onReattempt);
    extractTheme(wrap);
    return wrap;
  }

  function showRunningUI() {
    const sa = document.getElementById('cf-sw-start-area');
    const ra = document.getElementById('cf-sw-reattempt-area');
    if (sa) sa.style.display = 'none';
    if (ra) ra.style.display = '';
  }

  function showWaitingUI() {
    const sa = document.getElementById('cf-sw-start-area');
    const ra = document.getElementById('cf-sw-reattempt-area');
    if (sa) sa.style.display = '';
    if (ra) ra.style.display = 'none';
  }

  function tick() {
    if (!timerEl || !session) return;

    timerEl.textContent    = fmt(getElapsed());
    attemptsEl.textContent = `Attempt #${session.attempts}`;

    const dot = document.getElementById('cf-sw-dot');
    const txt = document.getElementById('cf-sw-status-text');

    if (session.state === 'solved') {
      timerEl.classList.add('cf-sw-solved');
      statusEl.className = 'cf-sw-status cf-sw-status--solved';
      if (dot) dot.style.display = 'none';
      if (txt) txt.textContent = 'Accepted';

    } else if (session.state === 'running') {
      timerEl.classList.remove('cf-sw-solved');
      statusEl.className = 'cf-sw-status cf-sw-status--running';
      if (dot) dot.style.display = '';
      if (txt) txt.textContent = 'Running';
      session.accumulated = getElapsed();
      runStartedAt = Date.now();
      persistSession();

    } else {
      timerEl.classList.remove('cf-sw-solved');
      statusEl.className = 'cf-sw-status';
      if (dot) dot.style.display = 'none';
      if (txt) txt.textContent = 'Ready';
    }
  }

  // ─── TRANSITIONS ─────────────────────────────────────────────────────────

  function startSolving() {
    stopCountdown();
    session.state            = 'running';
    session.accumulated      = 0;
    session.sessionStartedAt = Date.now();
    session.finalTimeMs      = 0;
    runStartedAt             = Date.now();
    persistSession();
    showRunningUI();
    startPolling();
    tick();
  }

  async function onReattempt() {
    reattemptBtn.disabled    = true;
    reattemptBtn.textContent = '…';
    stopPolling();
    stopCountdown();

    session.state            = 'waiting';
    session.accumulated      = 0;
    session.sessionStartedAt = null;
    session.finalTimeMs      = 0;
    session.attempts         = (session.attempts || 1) + 1;
    runStartedAt             = null;
    persistSession();

    timerEl.classList.remove('cf-sw-solved');
    showWaitingUI();
    beginCountdown();
    tick();

    reattemptBtn.disabled    = false;
    reattemptBtn.textContent = '↺ Reattempt';
  }

  async function onAccepted() {
    const finalMs       = getElapsed();
    session.state       = 'solved';
    session.finalTimeMs = finalMs;
    session.accumulated = finalMs;
    runStartedAt        = null;
    persistSession();
    stopPolling();
    tick();
    if (timerEl) {
      timerEl.classList.add('cf-sw-flash');
      setTimeout(() => timerEl.classList.remove('cf-sw-flash'), 1000);
    }
  }

  // ─── COUNTDOWN ───────────────────────────────────────────────────────────

  function beginCountdown() {
    countdownSecs = 60;
    updateHint();
    countdownId = setInterval(() => {
      countdownSecs--;
      updateHint();
      if (countdownSecs <= 0) {
        stopCountdown();
        startSolving();
      }
    }, 1000);
  }

  function stopCountdown() {
    if (countdownId) { clearInterval(countdownId); countdownId = null; }
  }

  function updateHint() {
    const h = document.getElementById('cf-sw-hint');
    if (h) h.textContent = countdownSecs > 0 ? `auto-starts in ${countdownSecs}s` : '';
  }

  // ─── VERDICT POLLING ─────────────────────────────────────────────────────

  function startPolling() {
    if (pollId || !handle) return;
    checkVerdict();
    pollId = setInterval(checkVerdict, 5000);
  }

  function stopPolling() {
    if (pollId) { clearInterval(pollId); pollId = null; }
  }

  async function checkVerdict() {
    if (!session || session.state !== 'running') return;
    try {
      const url = `https://codeforces.com/api/user.status?handle=${encodeURIComponent(handle)}&from=1&count=15`;
      const resp = await fetch(url);
      if (!resp.ok) return;
      const data = await resp.json();
      if (data.status !== 'OK') return;
      for (const sub of data.result) {
        if (String(sub.contestId) !== info.contestId) continue;
        if (sub.problem.index.toUpperCase() !== info.problemIndex) continue;
        if (sub.creationTimeSeconds * 1000 < session.sessionStartedAt) continue;
        if (sub.verdict === 'OK') { await onAccepted(); return; }
      }
    } catch (_) {}
  }

  // ─── PAGE LIFECYCLE ──────────────────────────────────────────────────────

  window.addEventListener('pagehide', () => {
    if (!session || session.state !== 'running') return;
    session.accumulated = getElapsed();
    persistSession();
  });

  // ─── UTILITIES ───────────────────────────────────────────────────────────

  function escHtml(s) {
    return String(s)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;')
      .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  // ─── THEME EXTRACTION ────────────────────────────────────────────────────

  function extractTheme(widget) {
    const cs = (el, prop) =>
      el ? getComputedStyle(el).getPropertyValue(prop).trim() : '';

    const roundbox  = document.querySelector('.roundbox');
    const roundHead = document.querySelector('.roundbox .roundbox-lt, .roundbox .top-title');
    const bodyEl    = document.body;
    const linkEl    = document.querySelector('a');

    let bg = cs(roundbox, 'background-color');
    if (!bg || bg === 'rgba(0, 0, 0, 0)' || bg === 'transparent')
      bg = cs(bodyEl, 'background-color');
    if (!bg || bg === 'rgba(0, 0, 0, 0)') bg = '#ffffff';

    let bgHead = cs(roundHead, 'background-color');
    if (!bgHead || bgHead === 'rgba(0, 0, 0, 0)')
      bgHead = isDark(bg) ? lighten(bg, 15) : darken(bg, 8);

    let border = cs(roundbox, 'border-top-color');
    if (!border || border === 'rgba(0, 0, 0, 0)')
      border = isDark(bg) ? lighten(bg, 25) : darken(bg, 20);

    let text = cs(roundbox, 'color') || cs(bodyEl, 'color') || '#333333';

    const headingEl =
      document.querySelector('.roundbox .roundbox-lt') ||
      document.querySelector('.roundbox .title') ||
      document.querySelector('.caption .title') ||
      document.querySelector('.second-level-menu-selected') ||
      document.querySelector('.roundbox-lt');
    let accent = cs(headingEl, 'color');
    if (!accent || accent === 'rgba(0, 0, 0, 0)' || accent === cs(bodyEl, 'color'))
      accent = cs(linkEl, 'color');
    if (!accent || accent === 'rgba(0, 0, 0, 0)')
      accent = isDark(bg) ? '#6699ff' : '#345391';

    const timerColor = isDark(bg) ? '#ffffff' : '#000000';

    const dark      = isDark(bg);
    const textMuted = blendHex(text, bg, 0.35);
    const textFaint = blendHex(text, bg, 0.6);
    const btnBg     = dark ? lighten(bg, 10) : darken(bg, 5);
    const btnHover  = dark ? lighten(bg, 20) : darken(bg, 12);
    const accentOk  = dark ? '#4ade80' : '#008000';

    const vars = {
      '--sw-bg':         bg,
      '--sw-bg-head':    bgHead,
      '--sw-border':     border,
      '--sw-text':       text,
      '--sw-text-muted': textMuted,
      '--sw-text-faint': textFaint,
      '--sw-accent':     accent,
      '--sw-accent-ok':  accentOk,
      '--sw-timer':      timerColor,
      '--sw-btn-bg':     btnBg,
      '--sw-btn-hover':  btnHover,
    };

    for (const [k, v] of Object.entries(vars)) {
      widget.style.setProperty(k, v);
    }
  }

  // ─── COLOUR HELPERS ──────────────────────────────────────────────────────

  function parseRgb(str) {
    let m = str.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
    if (m) return [+m[1], +m[2], +m[3]];
    m = str.match(/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})/i);
    if (m) return [parseInt(m[1],16), parseInt(m[2],16), parseInt(m[3],16)];
    return null;
  }

  function toHex([r,g,b]) {
    return '#' + [r,g,b].map(x => Math.max(0,Math.min(255,Math.round(x)))
      .toString(16).padStart(2,'0')).join('');
  }

  function isDark(color) {
    const rgb = parseRgb(color);
    if (!rgb) return false;
    const lum = (0.299*rgb[0] + 0.587*rgb[1] + 0.114*rgb[2]) / 255;
    return lum < 0.5;
  }

  function lighten(color, amt) {
    const rgb = parseRgb(color);
    if (!rgb) return color;
    return toHex(rgb.map(c => c + amt));
  }

  function darken(color, amt) {
    const rgb = parseRgb(color);
    if (!rgb) return color;
    return toHex(rgb.map(c => c - amt));
  }

  function blendHex(colorA, colorB, ratio) {
    const a = parseRgb(colorA), b = parseRgb(colorB);
    if (!a || !b) return colorA;
    return toHex(a.map((c, i) => c + (b[i] - c) * ratio));
  }

  // ─── INIT ────────────────────────────────────────────────────────────────

  async function init() {
    const saved = await loadSession();

    if (saved && saved.state) {
      session = saved;
      runStartedAt = (session.state === 'running') ? Date.now() : null;
    } else {
      session = {
        state:            'waiting',
        accumulated:      0,
        sessionStartedAt: null,
        attempts:         1,
        finalTimeMs:      0
      };
      runStartedAt = null;
      persistSession();
    }

    injectWidget();

    if (session.state === 'running' || session.state === 'solved') {
      showRunningUI();
    }

    tick();
    tickId = setInterval(tick, 1000);

    if (session.state === 'waiting') {
      beginCountdown();
    } else if (session.state === 'running') {
      startPolling();
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();