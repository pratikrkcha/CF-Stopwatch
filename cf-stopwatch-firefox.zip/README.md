# CF Stopwatch

A lightweight Firefox extension that automatically tracks how long you spend on each Codeforces problem. Stops on Accepted, survives tab switches, and lets you reattempt with one click.

---

## Features

- **Auto-start** — timer begins the moment a problem page loads, with a 60s countdown before it kicks in so you can read the problem first
- **Auto-stop** — stops automatically when your submission is Accepted
- **Persistent** — timer survives tab switches and page reloads
- **Reattempt** — resets timer to zero and increments attempt count with one click; old Accepted verdicts won't falsely stop the new attempt
- **Adaptive theme** — widget reads colours directly from the Codeforces page, so it blends seamlessly with any CF theme (light, dark, or custom)
---

## Installation

1. Open Firefox and go to `about:debugging`
2. Click **This Firefox** in the left sidebar
3. Click **Load Temporary Add-on…**
4. Navigate to the `cf-stopwatch` folder and select `manifest.json`
5. Open any Codeforces problem — the widget appears in the sidebar

> For a permanent install across restarts, sign the extension via [Mozilla Add-on Hub](https://addons.mozilla.org/developers/) or use Firefox Developer Edition with `xpinstall.signatures.required = false` in `about:config`.

```

**Verdict detection** polls `codeforces.com/api/user.status` every 5 seconds. It only triggers on submissions matching the current problem made after the current attempt started. You must be logged in to Codeforces for auto-stop to work.

**Timer model** — elapsed time is stored as a frozen snapshot (`accumulated`) that is updated every second and on page unload. The live `runStartedAt` timestamp is kept in memory only and never written to storage, so the timer picks up exactly where it left off after a reload without any drift.

---

## File structure

```
cf-stopwatch/
├── manifest.json   — Extension metadata and permissions
├── content.js      — Timer logic and widget injection
└── content.css     — Widget styles